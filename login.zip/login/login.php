<html>

<head>
	<link rel = "stylesheet" type = "text/css" href = "https://www.w3schools.com/w3css/4/w3.css">
	<link rel = "stylesheet" type = "text/css" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<?php

	$con = mysqli_connect('127.0.0.1','root','');

	if ( !$con ) {
		echo 'Cannot connect to the server';
	}

	// KAYO NA PONG BAHALA SA NAME NUNG SA DB.
	// Palitan niyo nalang po yung ' makder ' below
	if ( !mysqli_select_db ( $con, 'makder' ) ) {
		echo 'Database not selected';
	}

	$user = $_POST['user'];
	$passwd = $_POST['passwd'];

	// Pati din po itong table niya >> ' advisers '
	$sql = "INSERT INTO advisers (username, password) VALUES ('$user','$passwd')";

	if ( !mysqli_query($con, $sql) ) {
		// AYUSIN NIYO NALANG PO YUNG SA ' window.location = ? ' niya hehe

		echo "<script> alert('Failed to log in! Please try again.') ; window.location = 'instructor-hp.html' </script>";

	} else {
		// AYUSIN NIYO NALANG PO YUNG SA ' window.location = ? ' niya hehe

		echo "<script> alert('Welcome!') ; window.location = 'instructor-hp.html' </script>";
	}
?>

</html>